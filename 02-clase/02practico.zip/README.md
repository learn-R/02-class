# Actividad práctico 2

La actividad tendra relación con la entrega de la **Tarea 1**. Esta actividad consiste en la creación de un RMarkdown que contenga lo siguiente:

* Un encabezado (YAML) con el título: "Práctico 2". También deben incorporar su nombre y fecha

* Este encabezado debe tener una salida (output), debe ser en **html**

* En el código deben incorporar un chunk, en este deben llamar al grafico01 que se encuentra en el zip

* Finalmente, deben crear una tabla simple.
